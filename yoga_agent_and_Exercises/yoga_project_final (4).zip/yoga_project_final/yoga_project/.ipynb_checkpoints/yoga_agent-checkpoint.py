{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "710c34ed-8999-4edb-a1f6-32f8186e8a57",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "✅ Database created and populated.\n"
     ]
    }
   ],
   "source": [
    "import sqlite3\n",
    "\n",
    "def create_and_populate_db():\n",
    "    conn = sqlite3.connect(\"yoga_recommendation.db\")\n",
    "    cursor = conn.cursor()\n",
    "\n",
    "    # Drop old tables\n",
    "    cursor.execute(\"DROP TABLE IF EXISTS weekly_data\")\n",
    "    cursor.execute(\"DROP TABLE IF EXISTS users\")\n",
    "\n",
    "    # Create users table\n",
    "    cursor.execute('''\n",
    "    CREATE TABLE users (\n",
    "        user_id INTEGER PRIMARY KEY,\n",
    "        name TEXT,\n",
    "        gender TEXT,\n",
    "        age INTEGER,\n",
    "        height REAL,\n",
    "        weight REAL,\n",
    "        injury_history TEXT,\n",
    "        fitness_goal TEXT\n",
    "    )\n",
    "    ''')\n",
    "\n",
    "    # Create weekly_data table\n",
    "    cursor.execute('''\n",
    "    CREATE TABLE weekly_data (\n",
    "        user_id INTEGER,\n",
    "        session_date TEXT,\n",
    "        pose_accuracy REAL,\n",
    "        major_errors TEXT,\n",
    "        FOREIGN KEY(user_id) REFERENCES users(user_id)\n",
    "    )\n",
    "    ''')\n",
    "\n",
    "    # Insert sample users\n",
    "    users = [\n",
    "        (1, 'Aarav', 'Male', 25, 170, 60, 'ankle sprain', 'flexibility'),\n",
    "        (2, 'Isha', 'Female', 30, 160, 55, 'back pain', 'core strength'),\n",
    "        (3, 'Karan', 'Male', 35, 180, 78, 'none', 'weight loss'),\n",
    "        (4, 'Riya', 'Female', 28, 158, 52, 'knee pain', 'balance improvement'),\n",
    "        (5, 'Vikram', 'Male', 22, 175, 68, 'shoulder injury', 'muscle building')\n",
    "    ]\n",
    "    cursor.executemany(\"INSERT INTO users VALUES (?, ?, ?, ?, ?, ?, ?, ?)\", users)\n",
    "\n",
    "    # Insert weekly performance\n",
    "    weekly_data = [\n",
    "        (1, '2025-07-07', 85.0, 'trouble balancing on one leg'),\n",
    "        (1, '2025-07-08', 88.0, 'leg lift unstable'),\n",
    "        (2, '2025-07-07', 70.0, 'back pain'),\n",
    "        (2, '2025-07-08', 72.0, 'difficulty bending backward'),\n",
    "        (3, '2025-07-07', 90.0, 'minor wobble'),\n",
    "        (4, '2025-07-07', 60.0, 'cannot balance in tree pose'),\n",
    "        (5, '2025-07-08', 78.0, 'shoulder mobility issue')\n",
    "    ]\n",
    "    cursor.executemany(\"INSERT INTO weekly_data VALUES (?, ?, ?, ?)\", weekly_data)\n",
    "\n",
    "    conn.commit()\n",
    "    conn.close()\n",
    "    print(\"✅ Database created and populated.\")\n",
    "\n",
    "# Run this cell to create DB\n",
    "create_and_populate_db()\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "42ffd966-feb1-43b0-afa7-6e012d5636a3",
   "metadata": {},
   "outputs": [],
   "source": [
    "def add_user(user_id, name, gender, age, height, weight, injury_history, fitness_goal):\n",
    "    conn = sqlite3.connect(\"yoga_recommendation.db\")\n",
    "    cursor = conn.cursor()\n",
    "    \n",
    "    cursor.execute(\"INSERT INTO users VALUES (?, ?, ?, ?, ?, ?, ?, ?)\",\n",
    "                   (user_id, name, gender, age, height, weight, injury_history, fitness_goal))\n",
    "    \n",
    "    conn.commit()\n",
    "    conn.close()\n",
    "    print(f\"✅ User {name} added (ID: {user_id})\")\n",
    "\n",
    "def delete_user(user_id):\n",
    "    conn = sqlite3.connect(\"yoga_recommendation.db\")\n",
    "    cursor = conn.cursor()\n",
    "\n",
    "    cursor.execute(\"DELETE FROM weekly_data WHERE user_id = ?\", (user_id,))\n",
    "    cursor.execute(\"DELETE FROM users WHERE user_id = ?\", (user_id,))\n",
    "    \n",
    "    conn.commit()\n",
    "    conn.close()\n",
    "    print(f\"🗑️ User ID {user_id} deleted.\")\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "caba90e1-a407-46c7-b461-0687b5630d18",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "✅ User Meera added (ID: 6)\n",
      "🗑️ User ID 6 deleted.\n"
     ]
    }
   ],
   "source": [
    "# Add a new user\n",
    "add_user(6, \"Meera\", \"Female\", 29, 165, 58, \"wrist pain\", \"relieve stress\")\n",
    "\n",
    "# Delete a user (optional)\n",
    "delete_user(6)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "7fcaf83d-34e7-43d8-8b90-a9c29955c5c8",
   "metadata": {},
   "outputs": [],
   "source": [
    "def add_weekly_performance(user_id, session_date, pose_accuracy, major_errors):\n",
    "    conn = sqlite3.connect(\"yoga_recommendation.db\")\n",
    "    cursor = conn.cursor()\n",
    "\n",
    "    cursor.execute(\"\"\"\n",
    "        INSERT INTO weekly_data (user_id, session_date, pose_accuracy, major_errors)\n",
    "        VALUES (?, ?, ?, ?)\n",
    "    \"\"\", (user_id, session_date, pose_accuracy, major_errors))\n",
    "\n",
    "    conn.commit()\n",
    "    conn.close()\n",
    "    print(f\"📅 Session added for user ID {user_id} on {session_date}\")\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "id": "c3dd559e-1d75-44d9-b39b-4515e45e4c3b",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "📅 Session added for user ID 6 on 2025-07-14\n"
     ]
    }
   ],
   "source": [
    "# Example: Add a session for Meera (user_id = 6)\n",
    "add_weekly_performance(\n",
    "    user_id=6,\n",
    "    session_date=\"2025-07-14\",\n",
    "    pose_accuracy=67.5,\n",
    "    major_errors=\"difficulty balancing on one leg\"\n",
    ")\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "id": "85bc6311-f0fd-4f84-b606-dc60ee90d57f",
   "metadata": {},
   "outputs": [],
   "source": [
    "def get_user_sessions(user_id):\n",
    "    conn = sqlite3.connect(\"yoga_recommendation.db\")\n",
    "    cursor = conn.cursor()\n",
    "\n",
    "    cursor.execute(\"SELECT * FROM weekly_data WHERE user_id = ?\", (user_id,))\n",
    "    sessions = cursor.fetchall()\n",
    "    conn.close()\n",
    "\n",
    "    if not sessions:\n",
    "        print(f\"📭 No sessions found for user ID {user_id}\")\n",
    "    else:\n",
    "        print(f\"📊 Sessions for user ID {user_id}:\")\n",
    "        for s in sessions:\n",
    "            print(f\"Date: {s[1]}, Accuracy: {s[2]}, Errors: {s[3]}\")\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "id": "c9ea7521-78db-4304-9f5c-4a944bf840b4",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "📊 Sessions for user ID 6:\n",
      "Date: 2025-07-14, Accuracy: 67.5, Errors: difficulty balancing on one leg\n"
     ]
    }
   ],
   "source": [
    "get_user_sessions(6)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "id": "d835b767-bd6e-4a41-b7b0-dada2c287c53",
   "metadata": {},
   "outputs": [],
   "source": [
    "import sqlite3\n",
    "import whisper\n",
    "from datetime import datetime\n",
    "from collections import Counter\n",
    "import re\n",
    "\n",
    "# Load Whisper model once\n",
    "whisper_model = whisper.load_model(\"base\")\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "id": "8511e0b3-502e-41c1-8714-496d8814eb2d",
   "metadata": {},
   "outputs": [],
   "source": [
    "import os\n",
    "\n",
    "# ✅ Tell Python and Whisper where to find ffmpeg\n",
    "ffmpeg_exe_path = r\"C:\\ffmpeg\\ffmpeg-7.1.1-essentials_build\\bin\\ffmpeg.exe\"\n",
    "os.environ[\"IMAGEIO_FFMPEG_EXE\"] = ffmpeg_exe_path\n",
    "os.environ[\"PATH\"] += os.pathsep + os.path.dirname(ffmpeg_exe_path)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 10,
   "id": "d63ad235-43ba-48b8-8a6f-54162dd5259a",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "✅ ffmpeg is working!\n"
     ]
    }
   ],
   "source": [
    "import subprocess\n",
    "\n",
    "try:\n",
    "    subprocess.run([\"ffmpeg\", \"-version\"], check=True)\n",
    "    print(\"✅ ffmpeg is working!\")\n",
    "except FileNotFoundError:\n",
    "    print(\"❌ ffmpeg still not found\")\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 11,
   "id": "90ffcb25-ec2d-4d16-8bbf-f6fc7ba64dc8",
   "metadata": {},
   "outputs": [],
   "source": [
    "def transcribe_voice(audio_path):\n",
    "    result = whisper_model.transcribe(audio_path)\n",
    "    return result['text']\n",
    "\n",
    "def save_journal_entry(user_id, journal_text):\n",
    "    conn = sqlite3.connect(\"yoga_recommendation.db\")\n",
    "    cursor = conn.cursor()\n",
    "    cursor.execute(\"\"\"\n",
    "        CREATE TABLE IF NOT EXISTS journal_logs (\n",
    "            user_id INTEGER,\n",
    "            entry_date TEXT,\n",
    "            journal_text TEXT\n",
    "        )\n",
    "    \"\"\")\n",
    "    cursor.execute(\"\"\"\n",
    "        INSERT INTO journal_logs (user_id, entry_date, journal_text)\n",
    "        VALUES (?, ?, ?)\n",
    "    \"\"\", (user_id, datetime.now().strftime(\"%Y-%m-%d\"), journal_text))\n",
    "    conn.commit()\n",
    "    conn.close()\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 12,
   "id": "f4426586-6c05-48a0-83d5-f5f0dc47efd1",
   "metadata": {},
   "outputs": [],
   "source": [
    "def get_user_data(user_id):\n",
    "    conn = sqlite3.connect(\"yoga_recommendation.db\")\n",
    "    cursor = conn.cursor()\n",
    "\n",
    "    cursor.execute(\"SELECT name, age, gender, injury_history, fitness_goal FROM users WHERE user_id = ?\", (user_id,))\n",
    "    user = cursor.fetchone()\n",
    "\n",
    "    cursor.execute(\"SELECT pose_accuracy, major_errors FROM weekly_data WHERE user_id = ?\", (user_id,))\n",
    "    data = cursor.fetchall()\n",
    "\n",
    "    cursor.execute(\"SELECT journal_text FROM journal_logs WHERE user_id = ?\", (user_id,))\n",
    "    journal_entries = [row[0] for row in cursor.fetchall()]\n",
    "    conn.close()\n",
    "\n",
    "    accuracies = [d[0] for d in data]\n",
    "    errors = [d[1].lower() for d in data if d[1]]\n",
    "    avg_accuracy = sum(accuracies) / len(accuracies) if accuracies else 100\n",
    "    trend = \"improving\" if len(accuracies) >= 2 and accuracies[-1] > accuracies[-2] else \"stagnant\"\n",
    "    all_errors = \" \".join(errors)\n",
    "    recurring = [w for w in [\"back pain\", \"shoulder pain\", \"knee pain\"] if \" \".join(journal_entries).count(w) >= 3]\n",
    "\n",
    "    return {\n",
    "        \"name\": user[0], \"age\": user[1], \"gender\": user[2],\n",
    "        \"injury\": user[3], \"goal\": user[4],\n",
    "        \"avg_accuracy\": avg_accuracy,\n",
    "        \"accuracy_trend\": trend,\n",
    "        \"common_errors\": all_errors,\n",
    "        \"recurring_issues\": recurring\n",
    "    }\n",
    "\n",
    "def build_prompt(user, journal_text):\n",
    "    return f\"\"\"\n",
    "You're a yoga assistant.\n",
    "\n",
    "User: {user['name']}, Age: {user['age']}, Gender: {user['gender']}\n",
    "Injury: {user['injury']}\n",
    "Goal: {user['goal']}\n",
    "Average accuracy: {user['avg_accuracy']:.2f}% ({user['accuracy_trend']})\n",
    "Errors: {user['common_errors']}\n",
    "Recurring issues: {user['recurring_issues']}\n",
    "Journal: \\\"{journal_text}\\\"\n",
    "\n",
    "Instructions:\n",
    "1. Detect fatigue/injury.\n",
    "2. Suggest 2–3 yoga poses or rest.\n",
    "3. Suggest medical help if needed.\n",
    "4. Add a motivational quote.\n",
    "5. Mention: \\\"Follow tutorials in left panel.\\\"\n",
    "\"\"\"\n",
    "\n",
    "def run_tinyllama(prompt):\n",
    "    return \"\"\"\n",
    "🧘 You're doing your best! Balance needs attention, and back pain is recurring.\n",
    "\n",
    "Try:\n",
    "- Tree Pose\n",
    "- Cat-Cow\n",
    "- Savasana\n",
    "\n",
    "⚠️ Chronic pain detected. Consider medical advice.\n",
    "✨ \\\"Your body hears everything your mind says.\\\"\n",
    "Follow tutorials in the left panel.\n",
    "\"\"\"\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 13,
   "id": "b0c70ee9-e06e-42a3-bff2-9e41331aac71",
   "metadata": {},
   "outputs": [],
   "source": [
    "def recommend_yoga(user_id, journal_input, voice=False):\n",
    "    journal_text = transcribe_voice(journal_input) if voice else journal_input\n",
    "    save_journal_entry(user_id, journal_text)\n",
    "\n",
    "    user = get_user_data(user_id)\n",
    "    prompt = build_prompt(user, journal_text)\n",
    "    response = run_tinyllama(prompt)\n",
    "\n",
    "    print(\"🤖 Recommendation:\\n\", response)\n",
    "    return response\n",
    "\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 15,
   "id": "9cbdf192-bbc5-4081-9a41-99da21ccead3",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Collecting wordcloud\n",
      "  Downloading wordcloud-1.9.4-cp311-cp311-win_amd64.whl.metadata (3.5 kB)\n",
      "Requirement already satisfied: numpy>=1.6.1 in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from wordcloud) (2.1.3)\n",
      "Requirement already satisfied: pillow in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from wordcloud) (11.2.1)\n",
      "Requirement already satisfied: matplotlib in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from wordcloud) (3.10.1)\n",
      "Requirement already satisfied: contourpy>=1.0.1 in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from matplotlib->wordcloud) (1.3.2)\n",
      "Requirement already satisfied: cycler>=0.10 in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from matplotlib->wordcloud) (0.12.1)\n",
      "Requirement already satisfied: fonttools>=4.22.0 in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from matplotlib->wordcloud) (4.57.0)\n",
      "Requirement already satisfied: kiwisolver>=1.3.1 in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from matplotlib->wordcloud) (1.4.8)\n",
      "Requirement already satisfied: packaging>=20.0 in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from matplotlib->wordcloud) (24.2)\n",
      "Requirement already satisfied: pyparsing>=2.3.1 in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from matplotlib->wordcloud) (3.2.3)\n",
      "Requirement already satisfied: python-dateutil>=2.7 in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from matplotlib->wordcloud) (2.9.0.post0)\n",
      "Requirement already satisfied: six>=1.5 in c:\\users\\arpit\\appdata\\local\\packages\\pythonsoftwarefoundation.python.3.11_qbz5n2kfra8p0\\localcache\\local-packages\\python311\\site-packages (from python-dateutil>=2.7->matplotlib->wordcloud) (1.17.0)\n",
      "Downloading wordcloud-1.9.4-cp311-cp311-win_amd64.whl (299 kB)\n",
      "   ---------------------------------------- 0.0/299.9 kB ? eta -:--:--\n",
      "   ---------------------------------------- 0.0/299.9 kB ? eta -:--:--\n",
      "   - -------------------------------------- 10.2/299.9 kB ? eta -:--:--\n",
      "   - -------------------------------------- 10.2/299.9 kB ? eta -:--:--\n",
      "   - -------------------------------------- 10.2/299.9 kB ? eta -:--:--\n",
      "   --- ----------------------------------- 30.7/299.9 kB 163.8 kB/s eta 0:00:02\n",
      "   ----- --------------------------------- 41.0/299.9 kB 178.6 kB/s eta 0:00:02\n",
      "   --------- ----------------------------- 71.7/299.9 kB 261.4 kB/s eta 0:00:01\n",
      "   --------------- ---------------------- 122.9/299.9 kB 399.4 kB/s eta 0:00:01\n",
      "   ----------------------------- -------- 235.5/299.9 kB 684.7 kB/s eta 0:00:01\n",
      "   -------------------------------------- 299.9/299.9 kB 740.9 kB/s eta 0:00:00\n",
      "Installing collected packages: wordcloud\n",
      "Successfully installed wordcloud-1.9.4\n"
     ]
    },
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "  WARNING: The script wordcloud_cli.exe is installed in 'C:\\Users\\arpit\\AppData\\Local\\Packages\\PythonSoftwareFoundation.Python.3.11_qbz5n2kfra8p0\\LocalCache\\local-packages\\Python311\\Scripts' which is not on PATH.\n",
      "  Consider adding this directory to PATH or, if you prefer to suppress this warning, use --no-warn-script-location.\n",
      "\n",
      "[notice] A new release of pip is available: 24.0 -> 25.1.1\n",
      "[notice] To update, run: C:\\Users\\arpit\\AppData\\Local\\Microsoft\\WindowsApps\\PythonSoftwareFoundation.Python.3.11_qbz5n2kfra8p0\\python.exe -m pip install --upgrade pip\n"
     ]
    }
   ],
   "source": [
    "!pip install wordcloud\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "id": "b819dde3-81d0-4b6a-af9b-af715a1beb4c",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.9"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
