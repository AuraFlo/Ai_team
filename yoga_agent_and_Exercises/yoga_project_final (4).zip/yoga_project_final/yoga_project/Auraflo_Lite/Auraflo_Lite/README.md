1.  Create Python Virtual Environment (Recommended)

On macOS / Linux:

python3 -m venv auraflo_env
source auraflo_env/bin/activate

On Windows:

python -m venv auraflo_env
auraflo_env\Scripts\activate


2. Install Requirements

pip install -r requirements.txt


3. Run the Exercise Detection

python src/main.py

Press Q to quit the webcam session at any time.



📦 Dependencies

All required packages are listed in requirements.txt. Key libraries:
	•	opencv-python
	•	mediapipe
	•	numpy
	•	tensorflow (if using TFLite inference)