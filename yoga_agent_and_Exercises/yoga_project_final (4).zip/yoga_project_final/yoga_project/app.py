import streamlit as st
import sounddevice as sd
from scipy.io.wavfile import write
import tempfile
import os
from yoga_agent import recommend_yoga, generate_weekly_report

import cv2
import numpy as np
import tensorflow as tf
from movenet.movemodel import MoveNet  # Updated class name
from movenet.angl import calculate_angle

from movenet.movemodel import MoveNet
import sys
sys.path.append("Auraflo_Lite/Auraflo_Lite/src")
from session_logger import save_session_log



def load_pose_model():
    return MoveNet("movenet/movenet_lightning.tflite")  # Adjust path if needed


# Wrapper class to match our GUI usage
class MovenetModel:
    def __init__(self, model_path):
        self.model = MoveNet(model_path)

    def detect_pose(self, frame):
        return self.model.detect(frame)

# MoveNet keypoint indices
KEYPOINT_IDX = {
    "left_hip": 11, "left_knee": 13, "left_ankle": 15,
    "right_hip": 12, "right_knee": 14, "right_ankle": 16,
    "left_shoulder": 5, "right_shoulder": 6,
    "left_elbow": 7, "right_elbow": 8
}

# Extract angles for pose evaluation

def calculate_angles(keypoints):
    angle_dict = {}
    try:
        def get_point(name):
            return keypoints[KEYPOINT_IDX[name]][:2][::-1]  # (y, x) → (x, y)

        angle_dict["left_knee"] = calculate_angle(
            get_point("left_hip"), get_point("left_knee"), get_point("left_ankle")
        )
        angle_dict["right_knee"] = calculate_angle(
            get_point("right_hip"), get_point("right_knee"), get_point("right_ankle")
        )
        angle_dict["left_hip"] = calculate_angle(
            get_point("left_shoulder"), get_point("left_hip"), get_point("left_knee")
        )
        angle_dict["right_hip"] = calculate_angle(
            get_point("right_shoulder"), get_point("right_hip"), get_point("right_knee")
        )
        angle_dict["left_shoulder"] = calculate_angle(
            get_point("left_elbow"), get_point("left_shoulder"), get_point("left_hip")
        )
        angle_dict["right_shoulder"] = calculate_angle(
            get_point("right_elbow"), get_point("right_shoulder"), get_point("right_hip")
        )
    except Exception as e:
        pass  # skip if keypoints are missing or invalid
    return angle_dict

# Pose reference angles
POSE_REFERENCES = {
    "Tree Pose": {
        "left_knee": 90,
        "right_knee": 180,
        "left_hip": 180,
        "right_hip": 90,
        "left_shoulder": 180,
        "right_shoulder": 180
    },
    "Cobra Pose": {
        "left_knee": 180,
        "right_knee": 180,
        "left_hip": 90,
        "right_hip": 90,
        "left_shoulder": 90,
        "right_shoulder": 90
    }
}

# GUI helper function to trigger pose session

def run_pose_session(pose_name, reference_angles, video_url, model):
    st.video(video_url)
    st.markdown(f"### Now try the {pose_name}! Position yourself in front of the webcam")
    cap = cv2.VideoCapture(0)
    stframe = st.empty()
    frame_count, correct_count = 0, 0

    with st.spinner(f"📸 Checking your {pose_name}... Hold steady!"):
        while frame_count < 200:
            ret, frame = cap.read()
            if not ret:
                break

            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            keypoints = model.detect_pose(frame_rgb)
            angles = calculate_angles(keypoints)

            match_score = 0
            for joint, ref_angle in reference_angles.items():
                if joint in angles:
                    diff = abs(angles[joint] - ref_angle)
                    if diff < 20:
                        match_score += 1

            cv2.putText(frame, f"Match Score: {match_score}/{len(reference_angles)}", (20, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            if match_score >= len(reference_angles) - 1:
                correct_count += 1

            stframe.image(frame, channels="BGR")
            frame_count += 1

    cap.release()
    cv2.destroyAllWindows()
    accuracy = round((correct_count / frame_count) * 100, 2)
    st.success(f"✅ {pose_name} Accuracy: {accuracy}%")
    return accuracy

import sqlite3
from fpdf import FPDF
import speech_recognition as sr

def save_report(user_id, pose_name, accuracy):
    conn = sqlite3.connect("yoga_recommendation.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS pose_sessions (
            user_id INTEGER,
            pose TEXT,
            accuracy REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("INSERT INTO pose_sessions (user_id, pose, accuracy) VALUES (?, ?, ?)",
                   (user_id, pose_name, accuracy))
    conn.commit()
    conn.close()


def generate_pdf_report(user_id, pose_name, accuracy):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=14)
    pdf.cell(200, 10, txt=f"Yoga Session Report - {pose_name}", ln=1, align="C")
    pdf.ln(10)
    pdf.cell(200, 10, txt=f"User ID: {user_id}", ln=1)
    pdf.cell(200, 10, txt=f"Pose Name: {pose_name}", ln=1)
    pdf.cell(200, 10, txt=f"Pose Accuracy: {accuracy}%", ln=1)
    filename = f"report_user_{user_id}_{pose_name.replace(' ', '_')}.pdf"
    pdf.output(filename)
    st.success(f"📄 Report saved as {filename}")


import subprocess
import tempfile
import os

def recognize_pose_from_voice():
    st.info("🎙️ Speak the pose name (e.g., Tree Pose or Cobra Pose)")

    try:
        fs = 44100
        seconds = 5
        st.info("🎤 Recording for 5 seconds...")

        # Record audio
        audio = sd.rec(int(seconds * fs), samplerate=fs, channels=1, dtype='int16')
        sd.wait()

        # Save to temp .wav file
        temp_dir = tempfile.gettempdir()
        audio_path = os.path.join(temp_dir, "pose_audio.wav")
        write(audio_path, fs, audio)

        # Transcribe with whisper.cpp
        whisper_exe = "whisper/main.exe"  # Adjust this path if needed
        whisper_model = "ggml-base.en.bin"  # Ensure it's in same dir or full path
        result = subprocess.run([
            whisper_exe,
            "-m", whisper_model,
            "-f", audio_path,
            "-otxt",
            "-of", "pose_output"
        ], cwd=os.path.dirname(whisper_exe), capture_output=True)

        if result.returncode != 0:
            st.error("❌ Whisper transcription failed")
            return None

        # Read transcribed output
        transcript_path = os.path.join(os.path.dirname(whisper_exe), "pose_output.txt")
        if not os.path.exists(transcript_path):
            st.error("❌ Transcription file not found")
            return None

        with open(transcript_path, "r", encoding="utf-8") as f:
            transcript = f.read().lower()
            st.success(f"📝 Transcription: {transcript.strip()}")

            if "tree" in transcript:
                return "Tree Pose"
            elif "cobra" in transcript:
                return "Cobra Pose"
            else:
                st.warning("❓ Pose not recognized in voice")
                return None

    except Exception as e:
        st.error(f"🎤 Voice recognition error: {str(e)}")
        return None



# Streamlit configuration


# ---------------------------- Cute Custom CSS (Updated for visibility) ----------------------------
st.markdown("""
    <style>
    html, body, [class*="css"] {
        background-color: #001F24;  /* Deep dark blue background */
        font-family: "Segoe UI", sans-serif;
        color: #E0F7FA;
    }

    .main-title {
        font-size: 2.8em;
        font-weight: 700;
        text-align: center;
        color: #00363A;
        margin-bottom: 0.1em;
    }

    .sub-header {
        font-size: 1.2em;
        text-align: center;
        color:#00363A;
        margin-bottom: 2em;
    }

    .stButton > button {
        background-color: #014D4E;
        color: #E0F7FA;
        font-size: 16px;
        border-radius: 12px;
        padding: 0.5em 1.5em;
        transition: 0.3s ease-in-out;
        border: none;
    }

    .stButton > button:hover {
        background-color: #026466;
        color: #FFFFFF;
    }

    .stTextArea textarea {
        border-radius: 12px;
        background-color: #00363A;
        color: #E0F7FA;
    }

    .stSidebar > div:first-child {
        background-color: #002A2E;
        border-radius: 16px;
        padding: 1em;
        color: #E0F7FA;
    }

    .stSidebar label, .stSidebar span, .stSidebar input {
        color: #E0F7FA !important;
    }

    .stRadio > div > label {
        color: #E0F7FA !important;
    }

    .recommendation-box {
        background-color: #003B40;
        padding: 1.5em;
        border-radius: 12px;
        border-left: 4px solid #4EF0E7;
        margin: 1em 0;
    }

    .quote-box {
        background-color: #004D4D;
        padding: 1em;
        border-radius: 8px;
        font-style: italic;
        text-align: center;
        margin: 1em 0;
        color: #A7FFEB;
    }
    </style>
""", unsafe_allow_html=True)


# ---------------------------- Header ----------------------------
import base64

def get_base64_logo(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode()

logo_base64 = get_base64_logo("logo.png")

st.markdown(f"""
    <div style='text-align: center;'>
        <img src='data:image/png;base64,{logo_base64}' width='80'/>
        <div class='main-title'>Welcome to AuraFlo</div>
        <div class='sub-header'>Smart yoga, tuned to your body & rhythm🧘‍♀️</div>
    </div>
""", unsafe_allow_html=True)


# ---------------------------- Pose Buttons ----------------------------
# Replace your Pose Buttons section (around lines 300-315) with this:

# ---------------------------- Pose Buttons - UPDATED SECTION ----------------------------
st.subheader("🧘‍♀ Try a Pose")
pose_model = load_pose_model()

col1, col2 = st.columns(2)
with col1:
    if st.button("🌳 Start Tree Pose"):
        # Your exact file path
        video_path = os.path.join("yoga_project", "video", "tree_pose_video.mp4")
        
        # Check if file exists (for debugging)
        if os.path.exists(video_path):
            st.success(f"✅ Video found: {video_path}")
        else:
            st.error(f"❌ Video not found: {video_path}")
            video_path = None
        
        run_pose_session("Tree Pose", POSE_REFERENCES["Tree Pose"], video_path, pose_model)

with col2:
    if st.button("🐍 Start Cobra Pose"):
        # Your exact file path
        video_path = os.path.join("yoga_project", "video", "cobra_pose_tutorial.mp4")
        #yoga_project\video\tree_pose_video.mp4
        # Check if file exists (for debugging)
        if os.path.exists(video_path):
            st.success(f"✅ Video found: {video_path}")
        else:
            st.error(f"❌ Video not found: {video_path}")
            video_path = None
        
        run_pose_session("Cobra Pose", POSE_REFERENCES["Cobra Pose"], video_path, pose_model)


# ---------------------------- Sidebar ----------------------------
with st.sidebar:
    
    st.header("🌼 User Info")
    user_id = st.number_input("User ID", min_value=1, step=1, value=1)
    input_type = st.radio("How would you like to journal today?", ["Text", "Voice"])

# Initialize session state
if 'audio_path' not in st.session_state:
    st.session_state.audio_path = None

# ---------------------------- Journal Entry ----------------------------
st.subheader("📓 Journal Entry")
journal_text = ""
audio_path = None

if input_type == "Text":
    journal_text = st.text_area("Describe your current mood, pain, or thoughts:", height=150, 
                               placeholder="E.g., I feel tired today and my back is a bit sore...")
else:
    st.info("🎙️ Click to record ~5 seconds")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🎤 Start Voice Recording"):
            try:
                fs = 44100
                seconds = 5
                
                with st.spinner("🎤 Recording... Speak now!"):
                    audio = sd.rec(int(seconds * fs), samplerate=fs, channels=1, dtype='int16')
                    sd.wait()

                if audio is not None and len(audio) > 0:
                    temp_dir = tempfile.gettempdir()
                    audio_path = os.path.join(temp_dir, f"user_{user_id}_recording.wav")
                    write(audio_path, fs, audio)
                    st.session_state.audio_path = audio_path
                    st.success("🎉 Voice recorded successfully!")
                else:
                    st.error("❌ Recording failed - no audio captured.")
            except Exception as e:
                st.error(f"🎤 Recording Error: {str(e)}")
                st.info("💡 Make sure your microphone is connected and permissions are granted.")
    
    with col2:
        if st.session_state.audio_path and os.path.exists(st.session_state.audio_path):
            st.audio(st.session_state.audio_path)
            st.success("✅ Audio ready for analysis")
        else:
            st.info("No recording yet")

# ---------------------------- Recommendation ----------------------------
st.subheader("🌟 Your Personalized Yoga Plan")

if st.button("🌈 Get Recommendation", key="recommend_btn") and user_id:
    with st.spinner("✨ Analyzing your input and finding perfect poses..."):
        try:
            result = None
            
            if input_type == "Text" and journal_text.strip():
                result = recommend_yoga(user_id, journal_text, voice=False)
            elif input_type == "Voice":
                audio_path = st.session_state.get("audio_path", None)
                if audio_path and os.path.exists(audio_path):
                    result = recommend_yoga(user_id, audio_path, voice=True)
                else:
                    st.warning("⚠️ No voice recording found. Please record your voice first.")
                    result = None
            else:
                st.warning("⚠️ Please provide some input (text or voice) to get recommendations.")
                result = None

            if result:
                # Display recommendation in a nice box
                st.markdown('<div class="recommendation-box">', unsafe_allow_html=True)
                st.markdown("#### 💖 Your Personalized Recommendations:")
                st.markdown(result['details'])
                st.markdown('</div>', unsafe_allow_html=True)
                
                # Display motivational quote
                if 'quote' in result:
                    st.markdown(f'<div class="quote-box">💫 "{result["quote"]}"</div>', unsafe_allow_html=True)
                
                # Yoga video
                st.markdown("#### 🎥 Follow Along with This Gentle Yoga Session:")
                st.video("https://www.youtube.com/embed/v7AYKMP6rOE")
                
                # Additional tips
                st.markdown("#### 💡 Remember:")
                st.markdown("""
                - Listen to your body and don't push beyond your limits
                - Hold each pose for 30 seconds to 1 minute
                - Focus on your breathing throughout the practice
                - Stay hydrated and practice on an empty stomach
                """)
                
        except Exception as e:
            st.error(f"💔 Recommendation failed: {str(e)}")
            st.info("💡 Try again with different input, or check if all required files are properly configured.")

# ---------------------------- Weekly Report ----------------------------
st.subheader("📈 Your Weekly Progress")

if st.button("📊 Show Weekly Report", key="report_btn") and user_id:
    try:
        session_df, fatigue_df, error_counts = generate_weekly_report(user_id)

        if session_df.empty and fatigue_df.empty:
            st.info("📝 No weekly data found yet. Keep practicing to see your progress! 🌱")
            
            # Show some sample data structure
            st.markdown("#### 📋 What you'll see here:")
            st.markdown("""
            - **Pose Accuracy Trends**: Track how your form improves over time
            - **Fatigue Level Patterns**: Understand your energy cycles
            - **Common Areas for Improvement**: Focus on specific poses or techniques
            """)
        else:
            col1, col2 = st.columns(2)
            
            with col1:
                if not session_df.empty:
                    st.markdown("### 🔷 Pose Accuracy Over Time")
                    st.line_chart(session_df.rename(columns={"Date": "index"}).set_index("index"))
                else:
                    st.info("No pose accuracy data yet")

            with col2:
                if not fatigue_df.empty:
                    st.markdown("### 🔸 Estimated Fatigue Trends")
                    st.bar_chart(fatigue_df.rename(columns={"Date": "index"}).set_index("index"))
                else:
                    st.info("No fatigue data yet")

            if error_counts:
                st.markdown("### ⚠️ Most Common Areas to Focus On")
                for err, count in error_counts:
                    st.write(f"❌ **{err.capitalize()}**: {count} times")
            else:
                st.success("✅ No major errors recorded this week! Great job! 🎉")
                
    except Exception as e:
        st.error(f"💥 Error generating report: {str(e)}")
        st.info("💡 Reports will be available after you've used the app for a few days.")

# ---------------------------- Additional Features ----------------------------
st.subheader("🎯 Quick Actions")

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("🧘‍♀️ Morning Routine"):
        st.info("Perfect for starting your day with energy!")
        st.markdown("""
        **Suggested Morning Sequence:**
        1. Cat-Cow Pose (2 minutes)
        2. Downward Dog (1 minute)
        3. Warrior II (30s each side)
        4. Tree Pose (30s each side)
        """)

with col2:
    if st.button("😴 Evening Wind-Down"):
        st.info("Great for relaxing before bed!")
        st.markdown("""
        **Suggested Evening Sequence:**
        1. Child's Pose (2 minutes)
        2. Seated Forward Bend (1 minute)
        3. Legs Up the Wall (3 minutes)
        4. Corpse Pose (5 minutes)
        """)

with col3:
    if st.button("💪 Energy Boost"):
        st.info("When you need a quick energy lift!")
        st.markdown("""
        **Suggested Energy Sequence:**
        1. Bridge Pose (1 minute)
        2. Cobra Pose (30 seconds)
        3. Warrior II (1 minute)
        4. Tree Pose (1 minute)
        """)

# ---------------------------- Tips Section ----------------------------
with st.expander("💡 Yoga Tips & Guidelines"):
    st.markdown("""
    ### 🌟 Getting Started with Yoga
    
    **For Beginners:**
    - Start with 10-15 minute sessions
    - Focus on breathing and alignment over perfection
    - Use props (blocks, straps) when needed
    - Listen to your body and rest when needed
    
    **Safety First:**
    - Never force a pose
    - Stop if you feel pain (discomfort is okay, pain is not)
    - Warm up before deeper stretches
    - Cool down with relaxation poses
    
    **Making it a Habit:**
    - Practice at the same time each day
    - Start small and be consistent
    - Track your progress in this app
    - Celebrate small victories
    
    **When to Avoid Yoga:**
    - During acute injury or illness
    - If you have specific medical conditions (consult your doctor)
    - On a full stomach (wait 2-3 hours after large meals)
    """)

# ---------------------------- Settings ----------------------------
with st.expander("⚙️ App Settings"):
    st.markdown("### 🔧 Configuration")
    
    if st.button("🔄 Reset User Data"):
        if st.checkbox("I understand this will delete all my data"):
            try:
                import sqlite3
                conn = sqlite3.connect("yoga_recommendation.db")
                cursor = conn.cursor()
                cursor.execute("DELETE FROM journal_logs WHERE user_id = ?", (user_id,))
                cursor.execute("DELETE FROM weekly_data WHERE user_id = ?", (user_id,))
                conn.commit()
                conn.close()
                st.success("✅ User data reset successfully!")
            except Exception as e:
                st.error(f"❌ Error resetting data: {e}")
    
    st.markdown("### 📊 App Status")
    try:
        from yoga_agent import config
        st.write(f"📁 Database: {config.database_name}")
        st.write(f"🤖 Model: {config.model_file}")
        st.write(f"🎤 Whisper: {'Available' if os.path.exists(config.whisper_exe) else 'Not configured'}")
        
        # Check if tables exist
        import sqlite3
        conn = sqlite3.connect(config.database_name)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        st.write(f"📋 Database Tables: {', '.join(tables) if tables else 'None'}")
        
        # Count total entries
        if 'journal_logs' in tables:
            conn = sqlite3.connect(config.database_name)
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM journal_logs")
            count = cursor.fetchone()[0]
            conn.close()
            st.write(f"📝 Total Journal Entries: {count}")
    except Exception as e:
        st.error(f"❌ Status check failed: {e}")

# ---------------------------- AuraFlo Lite Workout Logger ----------------------------
st.subheader("🏋️ AuraFlo Lite Workout Logger")

from session_logger import save_session_log
from motivational import print_random_quote
from pushup_scoring import run_pushup_session
from bicep_curl import run_bicep_curl_session
from shutdown_handler import shutdown_system

# Arrange in 2 rows, 3 buttons each for better layout
row1_col1, row1_col2, row1_col3 = st.columns(3)
with row1_col1:
    if st.button("💪 Pushups"):
        run_pushup_session()
with row1_col2:
    if st.button("💪 Bicep Curls"):
        run_bicep_curl_session()
with row1_col3:
    if st.button("💾 Save Log"):
        save_session_log()

row2_col1, row2_col2, row2_col3 = st.columns(3)
with row2_col1:
    if st.button("💬 Inspire Me"):
        print_random_quote()
with row2_col2:
    if st.button("🔌 Shutdown"):
        shutdown_system()
with row2_col3:
    st.markdown(" ")  # Empty space for alignment




# ---------------------------- Footer ----------------------------
st.markdown("---")
st.markdown("""
    <div style='text-align: center; color:#002A2E ; padding: 1em;'>
        <h4>Made with 💕 for your wellbeing</h4>
        <p>© 2025 Yoga Assistant | Practice with mindfulness and self-compassion</p>
        <p><small>Remember: This app provides general wellness suggestions. 
        Always consult healthcare professionals for medical concerns.</small></p>
    </div>
""", unsafe_allow_html=True)

# ---------------------------- Sidebar Footer ----------------------------
with st.sidebar:
    st.markdown("---")
    st.markdown("### 🌟 Today's Intention")
    intentions = [
        "I am present in this moment",
        "I listen to my body with kindness",
        "I choose peace over perfection",
        "I am grateful for my body's strength",
        "I breathe in calm, breathe out tension"
    ]
    import random
    st.markdown(f"*{random.choice(intentions)}*")
    
    st.markdown("### 📱 Quick Stats")
    try:
        import sqlite3
        from yoga_agent import config
        conn = sqlite3.connect(config.database_name)
        cursor = conn.cursor()
        
        # Get user's journal count
        cursor.execute("SELECT COUNT(*) FROM journal_logs WHERE user_id = ?", (user_id,))
        journal_count = cursor.fetchone()[0]
        
        # Get latest fatigue level
        cursor.execute("""
            SELECT fatigue_level FROM journal_logs 
            WHERE user_id = ? 
            ORDER BY entry_date DESC 
            LIMIT 1
        """, (user_id,))
        latest_fatigue = cursor.fetchone()
        
        conn.close()
        
        st.metric("Journal Entries", journal_count)
        if latest_fatigue:
            fatigue_emoji = {"high": "😴", "medium": "😐", "low": "⚡"}.get(latest_fatigue[0], "😐")
            st.metric("Latest Fatigue", f"{latest_fatigue[0].title()} {fatigue_emoji}")
        
    except Exception as e:
        st.write("Stats will appear after first use")

# ---------------------------- Auto-initialization ----------------------------
# This runs when the app starts
if 'app_initialized' not in st.session_state:
    try:
        from yoga_agent import ensure_users_table_exists, ensure_weekly_data_table_exists, train_fatigue_classifier, config
        import os
        
        # Initialize database tables
        ensure_users_table_exists()
        ensure_weekly_data_table_exists()
        
        # Train model if it doesn't exist
        if not os.path.exists(config.model_file):
            with st.spinner("🤖 Setting up AI model for the first time..."):
                train_fatigue_classifier()
        
        st.session_state.app_initialized = True
        
    except Exception as e:
        st.error(f"⚠️ App initialization warning: {e}")
        st.info("The app will still work, but some features might be limited.")
# ---------------------------- AuraFlo Lite Workout Logger ----------------------------
